package com.example.tp_game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Sub13 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub13);
    }
}
