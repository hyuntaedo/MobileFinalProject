package com.example.tp_game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Sub9 extends AppCompatActivity {

    private boolean faildecision = true;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub9);
        Handler timer = new Handler();
        timer.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (faildecision){
                    Intent intent = new Intent(Sub9.this, Sub12.class);
                    startActivity(intent);
                    finish();
                }
            }
        },30000);


    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    public void Confirm9(View view) {
        EditText text = findViewById(R.id.editText5);
        if (text.getText().toString().equals("glass")) {
            Toast.makeText(this, "탈출!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, Sub13.class));
            faildecision = false;
        } else {
            Toast.makeText(this, "오답입니다", Toast.LENGTH_SHORT).show();
        }
    }
}
